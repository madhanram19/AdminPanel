import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const adminApi = createApi({
    reducerPath: "adminApi",
    baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:8000/" }),
    endpoints: (builder) => ({
      getUsers: builder.query({
        query: () => "users",
        providesTags: ["Admin"],
      }),  
      addContent: builder.mutation({
        query: (contentData) => ({
          url:'admin/contents',
          method:'POST',
          body: contentData,
        }),
        invalidatesTags: ["Admin"],
      }),  
    }),
  });

  export const {
    useGetUsersQuery, useAddContentMutation
  } = adminApi;
  