import React, { useState } from 'react'
import { CKEditor } from '@ckeditor/ckeditor5-react'
import ClassicEditor from '@ckeditor/ckeditor5-build-classic'

const CkEditor = () => {
  const [content, setContent] = useState(null)

  const handleData = (event, editor) =>{
    const data = editor.getData();
    setContent(data);
  }

  const handleSubmit = () => {
    console.log(content);
   }

  return (
    <div>
      {' '}
      <CKEditor
        editor={ClassicEditor}
    
        style={{ height: '200px' }}
        onChange={handleData}
      />
      <button className="btn btn-primary my-3" onClick={handleSubmit}>
        Submit
      </button>
    </div>
  )
}

export default CkEditor
