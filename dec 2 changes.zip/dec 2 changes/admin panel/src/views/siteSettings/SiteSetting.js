import React from 'react';
import { useNavigate } from 'react-router-dom';

const SiteSetting = () => {
    const navigate = useNavigate();
  return (
    <>
    <div>
      <h3>Add Content</h3>
      <button className='btn btn-primary mt-3' onClick={()=>navigate('/addcontent')}>Add Content</button>
    </div>
    <div className='mt-5'>
      {' '}
      <h2>Contents Table</h2>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">S.No</th>
            <th scope="col">Content ID</th>
    
            <th scope="col">Content</th>
          
            <th scope="col">Data</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="serial-no p-3">1</td>
            <td className="serial-no p-3"> </td>
            <td className="py-3">CopyRights</td>
            <td className="py-3"></td>
            <td>
              <button className="btn btn-primary" onClick={()=>navigate('/ckeditor')}>Edit</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    </>
  )
}

export default SiteSetting
