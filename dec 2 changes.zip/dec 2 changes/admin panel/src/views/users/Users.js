import React from 'react';
import { useGetUsersQuery } from '../../redux/services/adminAPI';

const Users = () => {
  const { data, isFetching } = useGetUsersQuery();
  const users = data?.data;

  if (isFetching) {
    return <div>Loading...</div>;
  }

  return (
    <div className="user-table-container">
      <h2>Users</h2>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">S.No</th>
            <th scope="col">ID</th>
            <th scope="col">Username</th>
            <th scope="col">Email</th>
            <th scope="col">Kyc Status</th>
            <th scope="col">Views</th>
          </tr>
        </thead>
        <tbody >
          {users.map((user, index) => (
            <tr key={user._id} >
              <td className="serial-no p-3">{index + 1}</td>
              <td className='p-3'>{user._id}</td>
              <td className='p-3'>{user.username}</td>
              <td className='p-3'>{user.email}</td>
              <td className='p-3'>{users[index].kyc.isApproved.toString()}</td>
              <td ><button className='btn btn-primary'>Kyc Details</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Users;
