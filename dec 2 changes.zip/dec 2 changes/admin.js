var express = require("express");
var router = express.Router();

const adminController = require('../controllers/adminController');

router.post("/contents", adminController.contents);

module.exports = router;