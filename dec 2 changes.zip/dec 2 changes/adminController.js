const Content = require('../model/contentModel');
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const { verifyToken } = require("../middlewares/verifyToken");
require("dotenv").config();
const multer = require("multer");
const path = require("path");
const { v4: uuidv4 } = require("uuid");

exports.contents = async (req, res) => {
    try {
     console.log(req.body);
     const { content, editorData } = req.body;

     const newContent = new Content({
        content,
        editorData
     })

     await newContent.save();
  
      res.status(200).json({ message: "Content Added Successfully!" });
    } catch (error) {
      res
        .status(400)
        .json({ message: "Something went wrong", error: error.message });
    }
  };